# Web Scraping
Lets learn web scraping and apply them in real application.
All the coding examples are for education purpose only.

**[Learn Web Scraping on Udemy](https://www.udemy.com/web-scraping-in-python/)**


**What you'll learn**

* Web Scraping in Python
* Web Data Storing
* Web Data Caching
* Python BeautifulSoup Library
* Python Scrapy Framework
* Creating Log File
* Object Oriented Program Design
* Aljazeera News Scraping
* Goodreads Quotes Scraping

