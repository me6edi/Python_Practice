# React Native Tutorial Series

## Beginner

1. [React Native tutorial](https://www.youtube.com/watch?v=kFEs5WB7NB0) / [Source Code](t1_helloworld/): Starting point to learn how to develop a basic hello world app.

2. [JavaScript ES6 / ES2015](https://youtu.be/7LnGAsErYYU): Some advanced and modern JavaScript syntax discussion required to work on react native