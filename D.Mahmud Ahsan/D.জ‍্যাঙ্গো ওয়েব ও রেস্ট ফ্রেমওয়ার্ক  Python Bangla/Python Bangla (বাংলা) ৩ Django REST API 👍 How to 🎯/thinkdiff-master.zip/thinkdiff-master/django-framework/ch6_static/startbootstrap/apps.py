from django.apps import AppConfig


class StartbootstrapConfig(AppConfig):
    name = 'startbootstrap'
