## My Daily Warm Up

> **Reptition is the mother of all skills**. As I have to work different tech at different time, sometimes I forget the key things.
> This is why I created this repo, to practice myself. I will do little things in random day, or repeating the same things,
> so that some key concepts remain fresh in my minds.

There is no standard rule for warming up. ***Experienced programmers suggest to do small things regularly.***

