
# author Mahmud Ahsan
# --------------------
#      msmath module under mspack package
# --------------------

def sum(x, y):
    return x + y 
    
def subtract(x, y):
    return x - y 
     
def multiplication(x, y):
    return x * y 
 
def division(x, y):
    return x / y 