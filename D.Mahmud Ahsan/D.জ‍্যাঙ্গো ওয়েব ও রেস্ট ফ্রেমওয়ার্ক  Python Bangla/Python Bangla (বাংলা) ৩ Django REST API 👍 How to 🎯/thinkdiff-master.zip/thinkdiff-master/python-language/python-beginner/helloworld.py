class X:
    def show(self, name):
        print("My name is: " + name)
        
x = X()
x.show("Ahsan")