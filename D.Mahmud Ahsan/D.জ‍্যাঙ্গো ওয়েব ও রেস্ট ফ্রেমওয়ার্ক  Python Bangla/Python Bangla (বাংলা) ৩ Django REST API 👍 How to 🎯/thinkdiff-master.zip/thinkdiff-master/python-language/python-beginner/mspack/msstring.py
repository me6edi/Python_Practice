# author Mahmud Ahsan
# --------------------
#      msstring module under mspack package
# --------------------

def full_name(first_name, last_name):
    return first_name + ' ' + last_name 
    
def print_chracters(str):
    for x in str:
        print (x)