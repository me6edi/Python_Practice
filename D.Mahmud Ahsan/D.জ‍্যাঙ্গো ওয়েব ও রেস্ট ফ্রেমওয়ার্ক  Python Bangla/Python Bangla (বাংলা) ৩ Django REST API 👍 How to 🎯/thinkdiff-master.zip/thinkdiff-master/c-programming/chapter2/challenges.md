## Challenge 1
#### Write down a complete C program to print the following output:
```
I am Bangladeshi.
I love my country.
I am proud for my country.
```

## Challenge 2
#### Write down a complete C program and create 4 variables: (1) an integer (2) a float (3) a double (4) a character. Now assign some values to each variable and print all the values and size of the variable data type.

> Sample Output (Your one may a bit different):
```
Integer: 45 and Size: 4 bytes
Float: 3030.33 and Size: 4 bytes
Double: 4.335 and Size: 8 bytes
Character: C and Size: 1 byte
```

## Challenge 3
#### Write a program that perform the following calculation: 3x + 5 + 25.5 where x = 5 and print the output. (hint: use %.2f in printf() to show only 2 digit after . )

> Sample Output
```
Result: 45.50
```