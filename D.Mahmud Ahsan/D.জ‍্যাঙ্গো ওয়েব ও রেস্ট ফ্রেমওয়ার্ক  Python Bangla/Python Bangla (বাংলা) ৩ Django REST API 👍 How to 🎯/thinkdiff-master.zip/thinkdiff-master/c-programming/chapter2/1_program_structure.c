/*
    Program Structure of C
    1. Preprocessor Directives
    2. main() function
    3. Curly brackets or braces
    4. Statements
    5. Comments
*/

// This is a Single Line Comment

#include <stdio.h>

int main(){ // or main(void)
    printf("I am serious..\n");
    return 0;
}