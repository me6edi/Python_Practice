/*
 * author: Mahmud Ahsan
 * https://github.com/mahmudahsan
 * blog: http://thinkdiff.net
 * http://banglaprogramming.com
 * License: MIT License
 */
 
/* 
 * Challenge 3
 */

 #include <stdio.h>

 int main(){
    int x = 5;
    float result = 3*x + 5 + 25.5;
    printf("Result: %.2f\n", result);

    return 0;
 }