/*
 * author: Mahmud Ahsan
 * https://github.com/mahmudahsan
 * blog: http://thinkdiff.net
 * http://banglaprogramming.com
 * License: MIT License
 */
 
/* 
 * Challenge 1
 */

 #include <stdio.h>

 int main(){
     printf("I am Bangladeshi.\n");
     printf("I love my country.\n");
     printf("I am proud for my country.\n");
     return 0;
 }